import React, { useRef, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { useStore } from '../../store'

export function AirflowStreamlines() {
  const { viewMode } = useStore()
  const isAirflowMode = viewMode === 'AIRFLOW'
  
  // Controlled number of subtle, slow airflow particles
  const particlesCount = isAirflowMode ? 18 : 6

  // Generate gentle convective particle paths entering the 10 vent holes at X = 2.26, Z = 1.2
  const particles = useMemo(() => {
    const list = []
    for (let i = 0; i < particlesCount; i++) {
      const zOffset = -0.8 + (i % 5) * 0.4 + (Math.random() - 0.5) * 0.08
      const yOffset = (i % 2 === 0 ? 0.1 : -0.1) + (Math.random() - 0.5) * 0.04
      list.push({
        start: new THREE.Vector3(4.5 + Math.random() * 1.2, yOffset + (Math.random() - 0.5) * 0.1, 1.2 + zOffset),
        mid: new THREE.Vector3(2.26, yOffset, 1.2 + zOffset * 0.9), // Enclosure 10-vent hole plane
        end: new THREE.Vector3(1.4, 0.12, i % 2 === 0 ? 0.5 : 1.5), // BME280 or ENS160 position
        speed: 0.22 + Math.random() * 0.15,
        offset: Math.random() * 2
      })
    }
    return list
  }, [particlesCount])

  const groupRef = useRef()

  useFrame((state) => {
    if (!groupRef.current) return
    const t = state.clock.elapsedTime
    groupRef.current.children.forEach((mesh, idx) => {
      const p = particles[idx]
      if (!p) return
      const progress = ((t * p.speed + p.offset) % 1)
      if (progress < 0.45) {
        const localT = progress / 0.45
        mesh.position.lerpVectors(p.start, p.mid, localT)
      } else {
        const localT = (progress - 0.45) / 0.55
        mesh.position.lerpVectors(p.mid, p.end, localT)
      }
      mesh.scale.setScalar(0.7 + Math.sin(progress * Math.PI) * 0.4)
    })
  })

  return (
    <group ref={groupRef}>
      {particles.map((_, idx) => (
        <mesh key={idx}>
          <sphereGeometry args={[0.038, 8, 8]} />
          <meshBasicMaterial 
            color={isAirflowMode ? '#2563eb' : '#4fa3b8'} 
            transparent 
            opacity={isAirflowMode ? 0.8 : 0.25} 
          />
        </mesh>
      ))}

      {/* Subtle convective streamlines shown only in Airflow mode */}
      {isAirflowMode && (
        <group>
          {[-0.6, 0, 0.6].map((z, i) => {
            const curve = new THREE.CatmullRomCurve3([
              new THREE.Vector3(4.6, 0.05, 1.2 + z),
              new THREE.Vector3(2.26, 0.05, 1.2 + z * 0.8),
              new THREE.Vector3(1.4, 0.12, 1.2 + z * 0.4)
            ])
            const pts = curve.getPoints(20)
            const geo = new THREE.BufferGeometry().setFromPoints(pts)
            return (
              <line key={i} geometry={geo}>
                <lineBasicMaterial color="#2563eb" transparent opacity={0.3} />
              </line>
            )
          })}
        </group>
      )}
    </group>
  )
}
