import React, { useRef, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { useStore } from '../../../store'

function DynamicParticle({ curveRef, color, speed = 1.2, active, size = 0.05 }) {
  const meshRef = useRef()
  const offset = useMemo(() => Math.random(), [])

  useFrame((state) => {
    if (!active || !meshRef.current || !curveRef.current) return
    const t = ((state.clock.elapsedTime * speed + offset) % 1)
    const pos = curveRef.current.getPoint(t)
    meshRef.current.position.copy(pos)
  })

  if (!active) return null

  return (
    <mesh ref={meshRef}>
      <sphereGeometry args={[size, 10, 10]} />
      <meshBasicMaterial color={color} toneMapped={false} />
    </mesh>
  )
}

function DynamicStreamLine({ startId, endId, color, active, isHighlighted }) {
  const { componentRefs } = useStore()
  const lineRef = useRef()
  const curveRef = useRef(new THREE.LineCurve3(new THREE.Vector3(), new THREE.Vector3()))

  const vStart = useMemo(() => new THREE.Vector3(), [])
  const vEnd = useMemo(() => new THREE.Vector3(), [])
  const vMid = useMemo(() => new THREE.Vector3(), [])

  useFrame(() => {
    if (!active || !lineRef.current) return
    const startObj = componentRefs[startId]?.current
    const endObj = componentRefs[endId]?.current
    if (!startObj || !endObj) return

    startObj.getWorldPosition(vStart)
    endObj.getWorldPosition(vEnd)

    // Gentle mid-point arching for realistic wiring conduit curvature
    vMid.lerpVectors(vStart, vEnd, 0.5)
    vMid.y += isHighlighted ? 0.35 : 0.22

    const curve = new THREE.QuadraticBezierCurve3(vStart.clone(), vMid.clone(), vEnd.clone())
    curveRef.current = curve
    const points = curve.getPoints(20)
    lineRef.current.geometry.setFromPoints(points)
  })

  if (!active) return null

  const opacity = isHighlighted ? 0.95 : 0.35
  const particleSpeed = isHighlighted ? 2.2 : 1.2
  const particleSize = isHighlighted ? 0.07 : 0.045

  return (
    <group>
      <line ref={lineRef}>
        <bufferGeometry />
        <lineBasicMaterial 
          color={color} 
          transparent 
          opacity={opacity} 
          linewidth={isHighlighted ? 3 : 1.5} 
        />
      </line>
      <DynamicParticle 
        curveRef={curveRef} 
        color={color} 
        speed={particleSpeed} 
        active={active} 
        size={particleSize}
      />
      {isHighlighted && (
        <DynamicParticle 
          curveRef={curveRef} 
          color="#ffffff" 
          speed={particleSpeed * 0.9} 
          active={active} 
          size={particleSize * 0.6}
        />
      )}
    </group>
  )
}

export function DynamicDataStreams({ isExploded }) {
  const { isAiCoreClicked, activeTab, riskLevel, selectedComponentId } = useStore()
  const isAiActive = isAiCoreClicked || activeTab === 'AI_CORE' || activeTab === 'SENSOR_FUSION'
  const riskColor = riskLevel === 'LOW' ? '#00ff88' : riskLevel === 'MEDIUM' ? '#ffcc00' : '#ff0044'

  // Determine if a connection line should be active and highlighted
  const checkStream = (idA, idB) => {
    const isSelected = selectedComponentId === idA || selectedComponentId === idB
    const active = isAiActive || isSelected
    return { active, isHighlighted: isSelected }
  }

  // 1. Health Stream: MAX30102 PPG -> ESP32-S3
  const healthStream = checkStream('MAX30102', 'ESP32_S3')

  // 2. Motion Stream: MPU6050 IMU -> ESP32-S3
  const motionStream = checkStream('MPU6050', 'ESP32_S3')

  // 3. Climate Stream: BME280 -> ESP32-S3
  const climateStream = checkStream('BME280', 'ESP32_S3')

  // 4. Air Quality Stream: ENS160 -> ESP32-S3
  const gasStream = checkStream('ENS160', 'ESP32_S3')

  // 5. Display Stream: ESP32-S3 -> OLED Display
  const displayStream = checkStream('ESP32_S3', 'OLED')

  // 6. Visual Alert Stream: ESP32-S3 -> RGB Light Pipe
  const rgbStream = checkStream('ESP32_S3', 'RGB_LED')

  // 7. Haptic Alert Stream: ESP32-S3 -> Vibration Motor
  const hapticStream = checkStream('ESP32_S3', 'VIBRATION_MOTOR')

  // 8. ECG Stream: AD8232 -> ESP32-S3
  const ecgStream = checkStream('AD8232', 'ESP32_S3')

  // 9. Medical Temp Stream: TMP117 -> ESP32-S3
  const tempStream = checkStream('TMP117', 'ESP32_S3')

  // 10. GPS Location Stream: NEO-6M -> ESP32-S3
  const gpsStream = checkStream('NEO_6M', 'ESP32_S3')

  // 11. Power Stream: Battery -> PMIC
  const pmicStream = checkStream('BATTERY', 'CHARGING_PCB')

  // 12. Regulated Power Rail: PMIC -> ESP32-S3
  const powerRailStream = checkStream('CHARGING_PCB', 'ESP32_S3')

  return (
    <group>
      {/* ECG Stream (AD8232 -> ESP32-S3) */}
      <DynamicStreamLine
        startId="AD8232"
        endId="ESP32_S3"
        color="#dc2626"
        active={ecgStream.active}
        isHighlighted={ecgStream.isHighlighted}
      />

      {/* Clinical Temperature Stream (TMP117 -> ESP32-S3) */}
      <DynamicStreamLine
        startId="TMP117"
        endId="ESP32_S3"
        color="#3b82f6"
        active={tempStream.active}
        isHighlighted={tempStream.isHighlighted}
      />

      {/* GPS Telemetry Stream (NEO-6M -> ESP32-S3) */}
      <DynamicStreamLine
        startId="NEO_6M"
        endId="ESP32_S3"
        color="#059669"
        active={gpsStream.active}
        isHighlighted={gpsStream.isHighlighted}
      />

      {/* Health Stream (MAX30102 PPG -> ESP32-S3) */}
      <DynamicStreamLine
        startId="MAX30102"
        endId="ESP32_S3"
        color="#ff0044"
        active={healthStream.active}
        isHighlighted={healthStream.isHighlighted}
      />

      {/* Motion Stream (MPU6050 IMU -> ESP32-S3) */}
      <DynamicStreamLine
        startId="MPU6050"
        endId="ESP32_S3"
        color="#2563eb"
        active={motionStream.active}
        isHighlighted={motionStream.isHighlighted}
      />

      {/* Climate Stream (BME280 -> ESP32-S3) */}
      <DynamicStreamLine
        startId="BME280"
        endId="ESP32_S3"
        color="#ffbb00"
        active={climateStream.active}
        isHighlighted={climateStream.isHighlighted}
      />

      {/* Air Quality Stream (ENS160 -> ESP32-S3) */}
      <DynamicStreamLine
        startId="ENS160"
        endId="ESP32_S3"
        color="#55ff88"
        active={gasStream.active}
        isHighlighted={gasStream.isHighlighted}
      />

      {/* Display Stream (ESP32-S3 -> 0.96" OLED) */}
      <DynamicStreamLine
        startId="ESP32_S3"
        endId="OLED"
        color="#00e5ff"
        active={displayStream.active}
        isHighlighted={displayStream.isHighlighted}
      />

      {/* Output Streams (ESP32-S3 -> RGB Light Pipe & Haptic Motor) */}
      <DynamicStreamLine
        startId="ESP32_S3"
        endId="RGB_LED"
        color={riskColor}
        active={rgbStream.active}
        isHighlighted={rgbStream.isHighlighted}
      />

      <DynamicStreamLine
        startId="ESP32_S3"
        endId="VIBRATION_MOTOR"
        color="#ff8800"
        active={hapticStream.active}
        isHighlighted={hapticStream.isHighlighted}
      />

      {/* Battery to PMIC Stream */}
      <DynamicStreamLine
        startId="BATTERY"
        endId="CHARGING_PCB"
        color="#ffcc00"
        active={pmicStream.active}
        isHighlighted={pmicStream.isHighlighted}
      />

      {/* Regulated 3.3V Power Stream to ESP32 */}
      <DynamicStreamLine
        startId="CHARGING_PCB"
        endId="ESP32_S3"
        color="#00ff88"
        active={powerRailStream.active}
        isHighlighted={powerRailStream.isHighlighted}
      />
    </group>
  )
}
